
  # Design from Image

  This is a code bundle for Design from Image. The original project is available at https://www.figma.com/design/wcNjsZCCrklJkMAr2iWPqp/Design-from-Image.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  