import { ImageWithFallback } from './components/figma/ImageWithFallback';
import { Twitter, Youtube, Linkedin, Instagram, Play } from 'lucide-react';

export default function App() {
  const projects = [
    {
      title: "Cyberpunk",
      subtitle: "Music Video",
      image: "https://images.unsplash.com/photo-1528109966604-5a6a4a964e8d?w=800&q=80",
      bgColor: "bg-[#ff0080]"
    },
    {
      title: "Action",
      subtitle: "Commercial",
      image: "https://images.unsplash.com/photo-1497015289639-54688650d173?w=800&q=80",
      bgColor: "bg-[#ff4500]"
    },
    {
      title: "Product",
      subtitle: "Tech Launch",
      image: "https://images.unsplash.com/photo-1632187981988-40f3cbaeef5e?w=800&q=80",
      bgColor: "bg-[#00d4ff]"
    },
    {
      title: "Automotive",
      subtitle: "Brand Film",
      image: "https://images.unsplash.com/photo-1574717025058-2f8737d2e2b7?w=800&q=80",
      bgColor: "bg-[#1a1a2e]"
    },
    {
      title: "Creative",
      subtitle: "Studio Reel",
      image: "https://images.unsplash.com/photo-1611784728558-6c7d9b409cdf?w=800&q=80",
      bgColor: "bg-[#8b5cf6]"
    },
    {
      title: "Event",
      subtitle: "Conference 2024",
      image: "https://images.unsplash.com/photo-1515634928627-2a4e0dae3ddf?w=800&q=80",
      bgColor: "bg-[#ef4444]"
    },
  ];

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-black">
      {/* Fixed Video Background */}
      <div className="fixed top-0 left-0 w-full h-screen">
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1603126004251-d01882b9bfd3?w=1600&q=80"
          alt="Video Background"
          className="w-full h-full object-cover"
        />
      </div>

      {/* Content that scrolls over video */}
      <div className="relative">
        {/* Spacer to allow video to show initially */}
        <div className="h-[40vh]"></div>

        {/* Main Content Section */}
        <div className="bg-white relative z-10">
          {/* Navigation */}
          <nav className="flex items-center justify-center gap-8 py-6 px-6 border-b border-gray-200">
            <a href="#work" className="text-sm tracking-wide opacity-60 hover:opacity-100 transition-opacity">
              WORK
            </a>
            <a href="#showreel" className="text-sm tracking-wide opacity-60 hover:opacity-100 transition-opacity">
              SHOWREEL + STILLS
            </a>
            <a href="#contact" className="text-sm tracking-wide opacity-60 hover:opacity-100 transition-opacity">
              CONTACT
            </a>
          </nav>

          {/* Projects Grid */}
          <section id="work" className="py-12 px-6">
            <div className="max-w-6xl mx-auto">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-0">
                {projects.map((project, index) => (
                  <div
                    key={index}
                    className="relative aspect-video overflow-hidden group cursor-pointer"
                  >
                    <div className={`absolute inset-0 ${project.bgColor} mix-blend-multiply z-10 transition-opacity duration-300 group-hover:opacity-70`}></div>
                    <ImageWithFallback
                      src={project.image}
                      alt={project.title}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />

                    {/* Large Play Button on Hover */}
                    <div className="absolute inset-0 z-30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300">
                      <div className="w-24 h-24 rounded-full bg-white/90 backdrop-blur-sm flex items-center justify-center transform scale-75 group-hover:scale-100 transition-transform duration-300 shadow-2xl">
                        <Play size={48} className="text-black fill-black ml-1" />
                      </div>
                    </div>

                    <div className="absolute inset-0 z-20 flex flex-col items-start justify-end p-8 text-white">
                      <h3 className="text-4xl mb-2">{project.title}</h3>
                      <p className="text-lg opacity-80">{project.subtitle}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          {/* Footer */}
          <footer className="py-12 px-6 border-t border-gray-200">
            <div className="max-w-6xl mx-auto">
              <div className="flex flex-col items-center gap-6">
                <button
                  onClick={scrollToTop}
                  className="text-sm opacity-60 hover:opacity-100 transition-opacity cursor-pointer"
                >
                  // Back to Top
                </button>
                <div className="flex gap-6 items-center">
                  <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="opacity-60 hover:opacity-100 transition-opacity">
                    <Twitter size={20} />
                  </a>
                  <a href="https://youtube.com" target="_blank" rel="noopener noreferrer" className="opacity-60 hover:opacity-100 transition-opacity">
                    <Youtube size={20} />
                  </a>
                  <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" className="opacity-60 hover:opacity-100 transition-opacity">
                    <Linkedin size={20} />
                  </a>
                  <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="opacity-60 hover:opacity-100 transition-opacity">
                    <Instagram size={20} />
                  </a>
                </div>
              </div>
            </div>
          </footer>
        </div>
      </div>
    </div>
  );
}
